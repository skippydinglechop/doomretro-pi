# DOOM Retro 6.3 for Batocera (Raspberry Pi 4B) - PortMaster style

The 6.3 zip is source code, and Batocera has no compiler, so it has to be built once on a PC
(Docker required; Windows users: WSL2 + Docker Desktop).

## 1. Build the ARM64 binary (on your PC)
    cd build
    ./build.sh /path/to/doomretro-6_3.zip
First run takes a few minutes (ARM is emulated unless your PC is ARM). If it says
"exec format error": `docker run --privileged --rm tonistiigi/binfmt --install arm64`
It writes the binary, `libs.aarch64/` and the resource wads into `ports/doomretro/`.

## 2. Copy to the Pi
Copy everything inside `ports/` to `/userdata/roms/ports/` so you end up with
`/userdata/roms/ports/Doom Retro.sh` next to `/userdata/roms/ports/doomretro/`.
(`chmod +x "Doom Retro.sh"` if your share doesn't keep permissions.)

## 3. Add game data
- IWADs (`doom.wad`, `doom2.wad`, ...) -> `doomretro/iwads/`
- Optional: a General MIDI `.sf2` -> `doomretro/soundfonts/` (otherwise music is silent)

Then Batocera: Update gamelists -> Ports -> Doom Retro.

## Controls
DOOM Retro reads the pad natively (SDL game controller). Select+Start quits (gptokeyb).
If your pad isn't picked up, set `USE_KEYMAP=1` at the top of `Doom Retro.sh` for a basic
keyboard-emulation mapping (`doomretro-keys.gptk`).

## What the build changes
- Default renderer on the Pi is OpenGL ES 2 (stock default is desktop OpenGL, which doesn't
  suit the Pi's KMSDRM output). If it can't start, DOOM Retro falls back to software
  rendering on its own. Change later with `vid_scaleapi` in the in-game console (`~`).
- Compiled with `-fsigned-char -fwrapv` (both required for correct DOOM behavior on ARM).
- Portable: config (`doomretro.cfg`) and savegames live in `ports/doomretro/`.

## Troubleshooting
Everything is logged to `ports/doomretro/log.txt`.
- `error while loading shared libraries: libXXX` -> set `PREFER_BUNDLED_LIBS=1` in the
  launcher, or tell me the lib name.
- `GLIBC_x.y not found` -> the build container's glibc is newer than the Pi's; the build
  prints the required version. Compare with `ldd --version` on the Pi.
- Black screen / no video -> uncomment `export SDL_VIDEODRIVER=kmsdrm` in the launcher, or
  set `vid_scaleapi "software"` in `doomretro.cfg`.
- No music -> add a `.sf2` (see above).

## Not tested on a real Pi
Verified in a sandbox: source builds and links on x86 Linux with the patch and flags,
the launcher logic (4 scenarios, stubbed PortMaster), and IWAD discovery. The ARM64 build,
the container steps and everything on real Batocera hardware have not been run.
