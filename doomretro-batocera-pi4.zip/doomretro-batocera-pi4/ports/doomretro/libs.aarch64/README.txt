Filled in by build/build.sh (SDL2_mixer + FluidSynth and their dependencies).
The launcher prefers the Pi's own libraries in /usr/lib and only falls back to these.
