Optional - needed only for MIDI music (sound effects work without it).

Drop any General MIDI soundfont (.sf2) in this folder. The launcher also looks for one in
/userdata/bios and a few system folders if this folder is empty.

DOOM Retro plays music through SDL_mixer, which uses FluidSynth for MIDI. Without a
soundfont the game runs fine but the music is silent.
