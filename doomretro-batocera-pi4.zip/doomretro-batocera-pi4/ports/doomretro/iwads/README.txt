Put your game data (IWADs) here, e.g.

  doom.wad  doom2.wad  plutonia.wad  tnt.wad  doom1.wad (shareware)  freedoom1.wad ...

DOOM Retro does not include any game data - you need your own copy
(Steam / GOG / the original CDs, or the free Freedoom).

- Names are lowercased automatically at launch (Linux is case-sensitive).
- With several IWADs here, DOOM Retro picks one itself (DOOM II first).
  To force one, create ../iwad.txt containing just its name, e.g.  doom
- Extra command-line options (PWADs, warp, skill...) can go in ../extra_args.txt,
  one line, e.g.  -file pwads/mymap.wad
