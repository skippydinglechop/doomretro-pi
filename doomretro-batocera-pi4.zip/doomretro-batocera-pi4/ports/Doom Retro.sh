#!/bin/bash
# PORTMASTER: doomretro.zip, Doom Retro.sh
#
# DOOM Retro 6.3 - PortMaster-style launcher for Batocera on Raspberry Pi 4B (aarch64).
# Put this file next to the "doomretro" folder in /userdata/roms/ports/

# ---- user options ----------------------------------------------------------
USE_KEYMAP=0            # 1 = emulate a keyboard with gptokeyb (only if your pad isn't
                        #     detected natively; uses doomretro-keys.gptk)
PREFER_BUNDLED_LIBS=0   # 1 = use libs.aarch64/ before the system libs in /usr/lib
# -----------------------------------------------------------------------------

SCRIPTDIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

XDG_DATA_HOME=${XDG_DATA_HOME:-$HOME/.local/share}

if   [ -d "/opt/system/Tools/PortMaster/" ];      then controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ];             then controlfolder="/opt/tools/PortMaster"
elif [ -d "$XDG_DATA_HOME/PortMaster/" ];         then controlfolder="$XDG_DATA_HOME/PortMaster"
elif [ -d "/userdata/roms/ports/PortMaster/" ];   then controlfolder="/userdata/roms/ports/PortMaster"
else                                                   controlfolder="/roms/ports/PortMaster"
fi

if [ ! -f "$controlfolder/control.txt" ]; then
  echo "PortMaster not found (looked for control.txt in $controlfolder)."
  exit 1
fi

source "$controlfolder/control.txt"
[ -f "${controlfolder}/mod_${CFW_NAME}.txt" ] && source "${controlfolder}/mod_${CFW_NAME}.txt"
type get_controls >/dev/null 2>&1 && get_controls

# The game folder sits right next to this script; fall back to PortMaster's $directory.
if [ -d "$SCRIPTDIR/doomretro" ]; then
  GAMEDIR="$SCRIPTDIR/doomretro"
else
  GAMEDIR="/$directory/ports/doomretro"
fi

cd "$GAMEDIR" || exit 1

> "$GAMEDIR/log.txt" && exec > >(tee "$GAMEDIR/log.txt") 2>&1

msg() {
  echo "$1"
  if type pm_message >/dev/null 2>&1; then pm_message "$1"; fi
  sleep 6
}

finish() {
  if type pm_finish >/dev/null 2>&1; then pm_finish; fi
}

# ---- sanity checks ------------------------------------------------------------
if [ ! -f ./doomretro ]; then
  msg "doomretro binary missing. Run build/build.sh on a PC first (see README)."
  finish; exit 1
fi
chmod +x ./doomretro 2>/dev/null

# DOOM Retro looks for lowercase names (doom2.wad, plutonia.wad, ...) on Linux.
for f in iwads/*; do
  [ -f "$f" ] || continue
  lower="${f,,}"
  [ "$f" != "$lower" ] && mv -n "$f" "$lower" 2>/dev/null
done

shopt -s nullglob
iwads=(iwads/*.wad)
shopt -u nullglob

if [ ${#iwads[@]} -eq 0 ]; then
  msg "No IWAD found. Copy doom.wad / doom2.wad etc. into ports/doomretro/iwads/"
  finish; exit 1
fi

# Which IWAD: iwad.txt (e.g. "doom" or "plutonia") wins; a lone unusual file is passed
# explicitly; otherwise DOOM Retro auto-picks (doom2 first).
IWAD_ARGS=()
if [ -f iwad.txt ]; then
  IWAD_ARGS=(-iwad "$(head -n1 iwad.txt | tr -d '\r\n')")
elif [ ${#iwads[@]} -eq 1 ]; then
  name="$(basename "${iwads[0]}")"
  IWAD_ARGS=(-iwad "${name%.wad}")
fi

EXTRA_ARGS=()
[ -f extra_args.txt ] && read -r -a EXTRA_ARGS < extra_args.txt

# ---- environment --------------------------------------------------------------
export DOOMWADDIR="$GAMEDIR/iwads"

LIBS="$GAMEDIR/libs.${DEVICE_ARCH:-aarch64}"
if [ "$PREFER_BUNDLED_LIBS" = "1" ]; then
  export LD_LIBRARY_PATH="$LIBS:/usr/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
else
  export LD_LIBRARY_PATH="/usr/lib:$LIBS${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
fi

[ -n "$sdl_controllerconfig" ] && export SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig"

# MIDI music goes through SDL_mixer and needs a General MIDI soundfont.
SF2="$(ls "$GAMEDIR"/soundfonts/*.[sS][fF]2 2>/dev/null | head -n1)"
if [ -z "$SF2" ]; then
  SF2="$(find /userdata/bios /usr/share/soundfonts /usr/share/sounds/sf2 -maxdepth 3 -iname '*.sf2' 2>/dev/null | head -n1)"
fi
if [ -n "$SF2" ]; then
  export SDL_SOUNDFONTS="$SF2"
  echo "Soundfont: $SF2"
else
  echo "No soundfont found - music will be silent (see soundfonts/README.txt)."
fi
[ -f timidity/timidity.cfg ] && export TIMIDITY_CFG="$GAMEDIR/timidity/timidity.cfg"

# Uncomment if SDL picks the wrong video backend:
# export SDL_VIDEODRIVER=kmsdrm

echo "IWAD args: ${IWAD_ARGS[*]:-(auto)}   extra args: ${EXTRA_ARGS[*]:-(none)}"

# ---- go -----------------------------------------------------------------------
# With no config file, gptokeyb only provides the standard Select+Start quit combo
# and DOOM Retro reads the pad natively through SDL.
if [ "$USE_KEYMAP" = "1" ]; then
  $GPTOKEYB "doomretro" -c "$GAMEDIR/doomretro-keys.gptk" &
else
  $GPTOKEYB "doomretro" &
fi

type pm_platform_helper >/dev/null 2>&1 && pm_platform_helper "$GAMEDIR/doomretro" >/dev/null

./doomretro "${IWAD_ARGS[@]}" "${EXTRA_ARGS[@]}"

finish
